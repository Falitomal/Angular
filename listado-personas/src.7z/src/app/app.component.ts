import { Component, OnInit } from '@angular/core';
import firebase from 'firebase/compat/app';
import { LoginService } from './login/login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  titulo = 'Listado de Personas';

  constructor(private loginService: LoginService) {}
  ngOnInit(): void {
    firebase.initializeApp({
      apiKey: 'AIzaSyCWT6dNKlIDf_uJg4LiUGdbX4C2YztrZOE',
      authDomain: 'listado-personas-c9b08.firebase.com',
    });
  }
  isAutenticado() {
    this.loginService.isAutenticado();
  }
  salir() {
    this.loginService.logout();
  }
}
