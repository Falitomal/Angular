import { Component, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoggingService } from '../../LoggingService.service';
import { Persona } from '../../persona.model';
import { PersonasService } from '../../personas.service';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css'],
})
export class FormularioComponent {
  //@Output() personaCreada = new EventEmitter<Persona>();

  nombreInput: string = '';
  apellidoInput: string = '';
  indice:number;
  modoEdicion:number;

  constructor(
    private logginService: LoggingService,
    private personasService: PersonasService,
    private router:Router,
    private route: ActivatedRoute
  ) {
    this.personasService.saludar.subscribe((indice: number) =>
      alert('el indice es: ' + indice)
    );
  }
  ngOnInit(){
  this.indice = this.route.snapshot.params['id'];
  this.modoEdicion = +this.route.snapshot.queryParams['modoEdicion'];
    if(this.modoEdicion != null && this.modoEdicion === 1){
    let persona: Persona = this.personasService.encontrarPersona(this.indice);
    this.nombreInput = persona.nombre;
    this.apellidoInput = persona.apellido;

  }
  }
  onGuardarPersona() {
    let persona1 = new Persona(this.nombreInput, this.apellidoInput);
    if(this.modoEdicion != null && this.modoEdicion === 1){
      this.personasService.modificarPersona(this.indice, persona1);
    }else{
      this.personasService.agregarPersona(persona1);

    }
    //this.logginService.enviarMensajeAConsola("Enviamos persona: " + persona1.nombre+ " apellido: "+ persona1.apellido) ;
    //this.personaCreada.emit(persona1);
    this.router.navigate(['personas'])
  }
  eliminarPersona(){
if(this.indice != null){
this.personasService.eliminarPersona(this.indice);
}
this.router.navigate(['personas']);
  }
}
