import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Persona } from './persona.model';

@Injectable()
export class DataServices {
  constructor(private httpClient: HttpClient) {}
  //cargar personas con firebase
  cargarPersonas(){
      return this.httpClient.get('https://listado-personas-c9b08-default-rtdb.europe-west1.firebasedatabase.app/datos.json');
  }
    modificarPersona(indice:number, persona: Persona){
        let url:string;
        url='https://listado-personas-c9b08-default-rtdb.europe-west1.firebasedatabase.app/datos/' + indice + '.json';
        this.httpClient.put(url, persona).subscribe(
            response => console.log("resultado de modificar estado eprsona"+ response)
        , error => console.log("error"+ error)
        )
    }


  //guardar personas con conexion firebase
  guardarPersonas(personas: Persona[]){
      this.httpClient.put('https://listado-personas-c9b08-default-rtdb.europe-west1.firebasedatabase.app/datos.json', personas)
      .subscribe(
          response =>console.log("resultado guardar personas:", +response),
          error => console.log("error al guardar persona" + error)
      );

  }
  eliminarPersona(indice:number){
    let url:string;
    url='https://listado-personas-c9b08-default-rtdb.europe-west1.firebasedatabase.app/datos/' + indice + '.json';
    this.httpClient.delete(url).subscribe(
        response => console.log("resultado de eliminar registro"+ response)
    , error => console.log("error en eliminar persona"+ error)
    )
  }
}
