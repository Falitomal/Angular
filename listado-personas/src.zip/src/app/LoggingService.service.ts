export class LoggingService{
    enviarMensajeAConsola(mensaje:string){
        console.log(mensaje);
    }
}