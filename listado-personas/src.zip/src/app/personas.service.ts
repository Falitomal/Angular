import { EventEmitter, Injectable } from '@angular/core';
import { DataServices } from './data.services';
import { LoggingService } from './LoggingService.service';
import { Persona } from './persona.model';
@Injectable()
export class PersonasService {
  personas: Persona[] = [];

  saludar = new EventEmitter<number>();
  constructor(
    private logginService: LoggingService,
    private dataServices: DataServices
  ) {}

  setPersonas(personas:Persona[]){
    this.personas = personas;
  }
  obtenerPersonas() {
    return this.dataServices.cargarPersonas();
  }
  agregarPersona(persona: Persona) {
    this.logginService.enviarMensajeAConsola(
      'agregamos persona: ' + persona.nombre
    );
    if(this.personas == null){
      this.personas = [];
    }
    this.personas.push(persona);
    this.dataServices.guardarPersonas(this.personas);
  }
  encontrarPersona(indice: number) {
    let persona: Persona = this.personas[indice];
    return persona;
  }
  modificarPersona(indice: number, persona: Persona) {
    let persona1 = this.personas[indice];
    persona1.nombre = persona.nombre;
    persona1.apellido = persona.apellido;
    this.dataServices.modificarPersona(indice, persona);
  }
  eliminarPersona(indice: number) {
    this.personas.splice(indice, 1);
    this.dataServices.eliminarPersona(indice);
    //reinciar los indices, se vuelve a guardar y regenerar los indices
    this.modificarPersonas();
  }
  modificarPersonas(){
    if(this.personas != null){
      this.dataServices.guardarPersonas(this.personas);
    }
  }
}
